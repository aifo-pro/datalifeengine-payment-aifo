<?php if (!defined('BILLING_MODULE')) die("Hacking attempt!");

/**
 * AIFO Payment Module for DataLifeEngine
 * Модуль оплати AIFO для DataLifeEngine
 * 
 * @package    AIFO
 * @author     AIFO.PRO
 * @copyright  Copyright (c) 2026 AIFO.PRO
 * @license    Proprietary
 */
class aifo
{
    var $doc = 'https://aifo.pro/docs';

    function Settings($config)
    {
        $html = [];

        $html[] = [
            'ID Магазину:',
            'З налаштувань магазину в особистому кабінеті AIFO',
            '<input name="save_con[shop_id]" class="edit bk" type="text" value="' . htmlspecialchars($config['shop_id'] ?? '') . '" style="width: 100%">',
        ];

        $html[] = [
            'Секретний ключ:',
            'З налаштувань магазину в особистому кабінеті AIFO',
            '<input name="save_con[secret_key]" class="edit bk" type="password" value="' . htmlspecialchars($config['secret_key'] ?? '') . '" style="width: 100%">',
        ];

        $html[] = [
            'Тип підпису:',
            'Виберіть тип хешування для підпису (MD5, SHA256, SHA1, RIPEMD160, SHA384, SHA512)',
            '<select name="save_con[signature_type]" class="edit bk" style="width: 100%">
                <option value="1"' . (($config['signature_type'] ?? 1) == 1 ? ' selected' : '') . '>MD5</option>
                <option value="2"' . (($config['signature_type'] ?? 1) == 2 ? ' selected' : '') . '>SHA256</option>
                <option value="3"' . (($config['signature_type'] ?? 1) == 3 ? ' selected' : '') . '>SHA1</option>
                <option value="4"' . (($config['signature_type'] ?? 1) == 4 ? ' selected' : '') . '>RIPEMD160</option>
                <option value="5"' . (($config['signature_type'] ?? 1) == 5 ? ' selected' : '') . '>SHA384</option>
                <option value="6"' . (($config['signature_type'] ?? 1) == 6 ? ' selected' : '') . '>SHA512</option>
            </select>',
        ];

        $html[] = [
            'URL сервісу AIFO:',
            'URL сервісу AIFO (за замовчуванням: https://aifo.pro)',
            '<input name="save_con[aifo_url]" class="edit bk" type="text" value="' . htmlspecialchars($config['aifo_url'] ?? 'https://aifo.pro') . '" style="width: 100%">',
        ];

        $html[] = [
            'IP фільтр:',
            'Список довірених IP-адрес (необов\'язково, для додаткової безпеки)',
            '<input name="save_con[ip_filter]" class="edit bk" type="text" value="' . htmlspecialchars($config['ip_filter'] ?? '') . '" style="width: 100%">',
        ];

        return $html;
    }

    function Form($order_id, $config, $invoice, $description, $DevTools)
    {
        $amount = number_format($invoice['invoice_pay'], 2, '.', '') * 1;

        if (empty($description)) {
            $description = 'Баланс ' . $invoice['invoice_user_name'];
        }
        
        $shop_id = $config['shop_id'];
        $secret_key = $config['secret_key'];
        $signature_type = isset($config['signature_type']) ? (int)$config['signature_type'] : 1;
        $aifo_url = isset($config['aifo_url']) ? trim($config['aifo_url']) : 'https://aifo.pro';
        
        // Генерация подписи в зависимости от типа
        $signature = '';
        if ($signature_type == 1) {
            $signature = md5($shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } elseif ($signature_type == 2) {
            $signature = hash('sha256', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } elseif ($signature_type == 3) {
            $signature = hash('sha1', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } elseif ($signature_type == 4) {
            $signature = hash('ripemd160', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } elseif ($signature_type == 5) {
            $signature = hash('sha384', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } elseif ($signature_type == 6) {
            $signature = hash('sha512', $shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        } else {
            $signature = md5($shop_id . ':' . $amount . ':' . $secret_key . ':' . $order_id);
        }
        
        $payment_url = rtrim($aifo_url, '/') . '/pay/';

        return '
            <form method="get" action="' . htmlspecialchars($payment_url) . '" accept-charset="UTF-8" id="paysys_form">
                <input type="hidden" name="shop_id" value="' . htmlspecialchars($shop_id) . '" />
                <input type="hidden" name="amount" value="' . htmlspecialchars($amount) . '" />
                <input type="hidden" name="id" value="' . htmlspecialchars($order_id) . '" />
                <input type="hidden" name="desc" value="' . htmlspecialchars($description) . '" />
                <input type="hidden" name="sign" value="' . htmlspecialchars($signature) . '" />
                <input type="submit" class="btn" value="Оплатити">
            </form>';
    }

    function check_id($data)
    {
        return $data["invoice"];
    }

    function check_ok($data)
    {
        return 'OK';
    }

    function check_out($data, $config, $invoice)
    {
        global $_REQUEST;

        // Проверка IP фильтра (если настроен)
        if (!empty($config['ip_filter'])) {
            $valid_ip = false;
            $sIP = str_replace(' ', '', $config['ip_filter']);
            $array_IP = explode(',', $sIP);
            if (isset($_SERVER["HTTP_X_REAL_IP"])) {
                $cur_ip = $_SERVER["HTTP_X_REAL_IP"];
            } elseif (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
                $cur_ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
            } else {
                $cur_ip = $_SERVER["REMOTE_ADDR"];
            }
            if (in_array($cur_ip, $array_IP)) {
                $valid_ip = true;
            }

            if (!$valid_ip) {
                return 'Error: ip_checked';
            }
        }
        
        $shop_id = $config['shop_id'];
        $secret_key = $config['secret_key'];
        $signature_type = isset($config['signature_type']) ? (int)$config['signature_type'] : 1;
        
        // Генерация подписи в зависимости от типа
        $signatureGen = '';
        if ($signature_type == 1) {
            $signatureGen = md5($shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } elseif ($signature_type == 2) {
            $signatureGen = hash('sha256', $shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } elseif ($signature_type == 3) {
            $signatureGen = hash('sha1', $shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } elseif ($signature_type == 4) {
            $signatureGen = hash('ripemd160', $shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } elseif ($signature_type == 5) {
            $signatureGen = hash('sha384', $shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } elseif ($signature_type == 6) {
            $signatureGen = hash('sha512', $shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        } else {
            $signatureGen = md5($shop_id . ':' . $_REQUEST['sum'] . ':' . $secret_key . ':' . $_REQUEST['invoice']);
        }

        if ((string)$signatureGen === (string)$_REQUEST["http_auth_signature"]) {
            return 200;
        } else {
            return 'Error: signature:: ' . $_REQUEST["http_auth_signature"] . ' != ' . $signatureGen;
        }
    }
}

$Paysys = new aifo;

