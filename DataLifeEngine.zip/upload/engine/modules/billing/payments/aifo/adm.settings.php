<?php
/**
 * DLE Billing - AIFO.PRO Payment Gateway
 *
 * @link          https://aifo.pro/docs
 * @author        AIFO.PRO
 * @copyright     Copyright (c) 2024, AIFO.PRO
 */

namespace Billing;

Class Aifo implements IPayment
{
    public string $doc = 'https://aifo.pro/docs';

    /**
     * Массив настроек для редактирования в админ.панели
     * @param array $config
     * @return array
     */
    public function Settings( array $config ) : array
    {
        $Form = [];
    
        $Form[] = [
            "ID магазина (shop_id):",
            "ID кассы, можно получить в настройках проекта в панели управления AIFO.PRO",
            "<input name=\"save_con[shop_id]\" class=\"form-control\" type=\"text\" value=\"" . htmlspecialchars($config['shop_id'] ?? '') ."\">"
        ];

        $Form[] = [
            "Публичный ключ:",
            "Публичный ключ из настроек проекта в панели управления AIFO.PRO (используется для создания подписи при формировании платежа)",
            "<input name=\"save_con[public_key]\" class=\"form-control\" type=\"text\" value=\"" . htmlspecialchars($config['public_key'] ?? '') ."\">"
        ];

        $Form[] = [
            "Секретный ключ:",
            "Секретный ключ из настроек проекта в панели управления AIFO.PRO (используется для проверки уведомлений об оплате)",
            "<input name=\"save_con[secret_key]\" class=\"form-control\" type=\"text\" value=\"" . htmlspecialchars($config['secret_key'] ?? '') ."\">"
        ];

        $Form[] = [
            "Алгоритм хеширования для подписи:",
            "Выберите алгоритм для создания подписи платежа. Рекомендуется SHA256",
            "<select name=\"save_con[hash_algorithm]\" class=\"uniform\">
                <option value=\"sha256\" " . ( ($config['hash_algorithm'] ?? 'sha256') == 'sha256' ? "selected" : "" ) . ">SHA256 (рекомендуется)</option>
                <option value=\"sha1\" " . ( ($config['hash_algorithm'] ?? '') == 'sha1' ? "selected" : "" ) . ">SHA1</option>
                <option value=\"sha384\" " . ( ($config['hash_algorithm'] ?? '') == 'sha384' ? "selected" : "" ) . ">SHA384</option>
                <option value=\"sha512\" " . ( ($config['hash_algorithm'] ?? '') == 'sha512' ? "selected" : "" ) . ">SHA512</option>
                <option value=\"ripemd160\" " . ( ($config['hash_algorithm'] ?? '') == 'ripemd160' ? "selected" : "" ) . ">RIPEMD160</option>
                <option value=\"md5\" " . ( ($config['hash_algorithm'] ?? '') == 'md5' ? "selected" : "" ) . ">MD5 (не рекомендуется, устарел)</option>
            </select>"
        ];

        $Form[] = [
            "Валюта платежа:",
            "Валюта платежа по стандарту ISO 4217",
            "<select name=\"save_con[currency]\" class=\"uniform\">
                <option value=\"UAH\" " . ( ($config['currency'] ?? 'UAH') == 'UAH' ? "selected" : "" ) . ">UAH (Гривна)</option>
                <option value=\"USD\" " . ( ($config['currency'] ?? '') == 'USD' ? "selected" : "" ) . ">USD (Доллар)</option>
                <option value=\"EUR\" " . ( ($config['currency'] ?? '') == 'EUR' ? "selected" : "" ) . ">EUR (Евро)</option>
                <option value=\"RUB\" " . ( ($config['currency'] ?? '') == 'RUB' ? "selected" : "" ) . ">RUB (Рубль)</option>
            </select>"
        ];

        $Form[] = [
            "Примечание:",
            "<strong>Важно:</strong> В настройках кассы в панели управления AIFO.PRO необходимо указать URL для уведомлений (webhook).<br><br>Этот URL будет показан в разделе интеграции ниже. Укажите его в настройках кассы AIFO.PRO как Success URL и Fail URL.<br><br>Уведомления от AIFO.PRO приходят с POST параметрами: <code>sum</code>, <code>invoice</code>, <code>http_auth_signature</code>",
            "<div style=\"padding: 10px; background-color: #f9f9f9; border-left: 4px solid #007bff; margin: 10px 0;\">
                <strong>IP адрес сервера AIFO.PRO:</strong> 77.83.102.155<br>
                <strong>Метод проверки подписи:</strong> hash(algorithm, \"shop_id:amount:secret_key:invoice_id\")<br>
                <strong>Поддерживаемые алгоритмы:</strong> SHA256 (рекомендуется), SHA1, SHA384, SHA512, RIPEMD160, MD5 (устарел)
            </div>"
        ];

        return $Form;
    }

    /**
     * Форма с данными для отправки на сайт платежной системы
     * @param int $id
     * @param array $config_payment
     * @param array $invoice
     * @param string $currency
     * @param string $desc
     * @return string
     */
    public function Form( int $id, array $config_payment, array $invoice, string $currency, string $desc ) : string
    {
        // Получаем необходимые параметры из конфигурации
        $shop_id = isset($config_payment['shop_id']) ? trim($config_payment['shop_id']) : '';
        $public_key = isset($config_payment['public_key']) ? trim($config_payment['public_key']) : '';
        $hash_algorithm = isset($config_payment['hash_algorithm']) ? trim($config_payment['hash_algorithm']) : 'sha256';
        
        // Проверяем наличие обязательных параметров
        if (empty($shop_id) || empty($public_key)) {
            return '<div class="alert alert-danger">Ошибка: не настроены ID магазина или публичный ключ. Пожалуйста, проверьте настройки платежной системы.</div>';
        }

        // Форматируем сумму до 2 знаков после запятой (согласно документации API)
        $amount = number_format(floatval($invoice['invoice_pay']), 2, '.', '');
        $pay_id = $id;

        // Проверяем, что алгоритм поддерживается
        $supported_algorithms = array('sha256', 'sha1', 'sha384', 'sha512', 'ripemd160', 'md5');
        if (!in_array(strtolower($hash_algorithm), $supported_algorithms)) {
            $hash_algorithm = 'sha256'; // Используем SHA256 по умолчанию
        }

        // Формируем подпись согласно API AIFO.PRO
        // Формат: "ID Магазину:Сума:публічний ключ:Номер Рахунку"
        // Согласно документации: https://aifo.pro/docs
        $sign_string = $shop_id . ':' . $amount . ':' . $public_key . ':' . $pay_id;
        $sign = hash($hash_algorithm, $sign_string);

        // URL для оплаты согласно API AIFO.PRO
        $payment_url = 'https://aifo.pro/pay/';
        
        // Параметры для передачи (обязательные: shop_id, pay_id, amount, sign)
        $params = array(
            'shop_id' => $shop_id,
            'pay_id' => $pay_id,
            'amount' => $amount,
            'sign' => $sign
        );

        // Добавляем описание, если оно указано (необязательный параметр)
        if (!empty($desc)) {
            $params['desc'] = htmlspecialchars($desc);
        }

        // Формируем URL с параметрами (GET запрос)
        $payment_url .= '?' . http_build_query($params);

        // Формируем форму для автоматической перенаправления на страницу оплаты
        $form = '<form name="aifo_payment" method="get" id="paysys_form" action="' . htmlspecialchars($payment_url) . '">';
        $form .= '<input type="submit" class="btn btn-primary" value="Перейти к оплате на AIFO.PRO">';
        $form .= '</form>';
        
        // Автоматически отправляем форму через JavaScript
        $form .= '<script type="text/javascript">';
        $form .= 'document.addEventListener("DOMContentLoaded", function() {';
        $form .= '    var form = document.getElementById("paysys_form");';
        $form .= '    if (form) { form.submit(); }';
        $form .= '});';
        $form .= '</script>';

        return $form;
    }

    /**
     * ID квитанции из данных, полученных от сервера платежной системы
     * @param array $result
     * @return int
     */
    public function check_id( array $result ) : int
    {
        // AIFO.PRO отправляет номер рахунку в параметре 'invoice'
        if (isset($result['invoice'])) {
            return intval($result['invoice']);
        }

        // Если параметр invoice отсутствует, пробуем другие варианты
        if (isset($result['pay_id'])) {
            return intval($result['pay_id']);
        }

        return 0;
    }

    /**
     * Статус оплаты на запрос от платежной системы
     * @param array $result
     * @return string
     */
    public function check_ok( array $result ) : string
    {
        // AIFO.PRO ожидает ответ в формате 'OK' + номер счета
        $invoice_id = $this->check_id($result);
        return 'OK' . $invoice_id;
    }
    
    /**
     * Проверяет принятые от платежной системы данные
     * В случае успешной проверки - возвращает (bool) true, иначе - (string)сообщение об ошибке
     * @param array $result
     * @param array $config_payment
     * @param array $invoice
     * @return string|bool
     */
    public function check_out( array $result, array $config_payment, array $invoice ) : string|bool
    {
        // Получаем IP адрес клиента с учетом Cloudflare и прокси
        $client_ip = $this->getClientIP();

        // Проверка IP адреса сервера AIFO.PRO
        // Согласно документации AIFO.PRO: https://aifo.pro/docs
        $allowed_ips = array('77.83.102.155');
        
        if (!in_array($client_ip, $allowed_ips)) {
            return "hacking attempt! Invalid IP: " . $client_ip . " (Expected: 77.83.102.155)";
        }

        // Получаем параметры из уведомления (AIFO.PRO отправляет POST параметры)
        // Параметры: sum, invoice, http_auth_signature
        $sum = isset($result['sum']) ? trim($result['sum']) : '';
        $invoice_id = isset($result['invoice']) ? intval($result['invoice']) : 0;
        $http_auth_signature = isset($result['http_auth_signature']) ? trim($result['http_auth_signature']) : '';

        // Проверяем наличие обязательных параметров
        if (empty($sum) || $invoice_id <= 0 || empty($http_auth_signature)) {
            return "Missing required parameters. Received: sum=" . ($sum ?: 'empty') . ", invoice=" . $invoice_id . ", http_auth_signature=" . ($http_auth_signature ? 'present' : 'empty');
        }

        // Проверяем соответствие номера счета
        if ($invoice_id != $invoice['invoice_id']) {
            return "Invoice ID mismatch. Expected: " . $invoice['invoice_id'] . ", received: " . $invoice_id;
        }

        // Проверяем соответствие суммы платежа (допускаем небольшую погрешность из-за округления)
        $expected_amount = floatval($invoice['invoice_pay']);
        $received_amount = floatval($sum);
        
        // Используем точное сравнение с учетом округления до 2 знаков
        if (abs($expected_amount - $received_amount) > 0.01) {
            return "Amount mismatch. Expected: " . number_format($expected_amount, 2, '.', '') . ", received: " . number_format($received_amount, 2, '.', '');
        }

        // Получаем секретный ключ
        $secret_key = isset($config_payment['secret_key']) ? trim($config_payment['secret_key']) : '';
        if (empty($secret_key)) {
            return "Secret key is not configured";
        }

        // Получаем shop_id
        $shop_id = isset($config_payment['shop_id']) ? trim($config_payment['shop_id']) : '';
        if (empty($shop_id)) {
            return "Shop ID is not configured";
        }

        // Алгоритм хеширования (используем тот же, что и при создании платежа, по умолчанию SHA256)
        // Поддерживаемые алгоритмы: SHA256 (рекомендуется), SHA1, SHA384, SHA512, RIPEMD160, MD5 (устарел)
        $hash_algorithm = isset($config_payment['hash_algorithm']) ? trim($config_payment['hash_algorithm']) : 'sha256';
        
        // Проверяем, что алгоритм поддерживается
        $supported_algorithms = array('sha256', 'sha1', 'sha384', 'sha512', 'ripemd160', 'md5');
        if (!in_array(strtolower($hash_algorithm), $supported_algorithms)) {
            $hash_algorithm = 'sha256'; // Используем SHA256 по умолчанию, если алгоритм не поддерживается
        }

        // Формируем подпись для проверки согласно API AIFO.PRO
        // Формат: "ID Магазину:Сума:Секретний ключ:Номер Рахунку"
        $sign_string = $shop_id . ':' . number_format($received_amount, 2, '.', '') . ':' . $secret_key . ':' . $invoice_id;
        $calculated_signature = hash($hash_algorithm, $sign_string);

        // Проверяем подпись безопасным способом (предотвращает атаки по времени)
        if (!hash_equals($calculated_signature, $http_auth_signature)) {
            return "wrong sign! Check your secret key and hash algorithm settings. Algorithm: " . $hash_algorithm;
        }

        // Все проверки пройдены успешно
        return true;
    }

    /**
     * Получить реальный IP адрес клиента
     * Согласно документации AIFO.PRO: https://aifo.pro/docs
     * @return string
     */
    private function getClientIP() : string
    {
        // Согласно документации AIFO.PRO, проверяем HTTP_CF_CONNECTING_IP для Cloudflare
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $_SERVER['REMOTE_ADDR'] = $_SERVER['HTTP_CF_CONNECTING_IP'];
            return $_SERVER['REMOTE_ADDR'];
        }

        // Проверяем X-Real-IP (nginx proxy)
        if (isset($_SERVER['HTTP_X_REAL_IP'])) {
            return $_SERVER['HTTP_X_REAL_IP'];
        }

        // Проверяем X-Forwarded-For (если запрос проходит через прокси)
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($ips[0]);
        }

        // Возвращаем стандартный REMOTE_ADDR
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}

$Paysys = new Aifo;
